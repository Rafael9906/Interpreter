package edu.unbosque.interpreter.ast;

public interface AST {
	
	public String toString();
}
