package edu.unbosque.interpreter.ast;

public class ArithmeticOperator extends Operator {
	
	public ArithmeticOperator(String operator) {
		super(operator);
	}	

}
