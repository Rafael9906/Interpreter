package edu.unbosque.interpreter.ast;

public abstract class Value implements AST{
	
	public abstract int interpret();

}
