package edu.unbosque.interpreter.ast;

public class BooleanOperator extends Operator{
	
	public BooleanOperator(String operator) {
		super(operator);
	}

}
